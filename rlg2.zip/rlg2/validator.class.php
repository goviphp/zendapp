<?php
require_once("configuration.class.php");

class Validator extends Configuration
{
    private $file_name;

    function __construct($fileName)
    {
        parent::__construct();
        $this->file_name = $fileName;
    }

    private function getMimeTypes()
    {
        return array(
            'text/csv',
            'text/plain',
            'application/csv',
            'text/comma-separated-values',
            'application/excel',
            'application/vnd.ms-excel',
            'application/vnd.msexcel',
            'text/anytext',
            'application/octet-stream',
            'application/txt',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        );
    }

    public function checkUploadedFile()
    {
        if ($_FILES[$this->file_name]["error"] == 0) {
            if (!$this->checkFileType() || !$this->checkFileSize()) {
                return 1;
            }
        }
        return 0;
    }

    private function checkFileType()
    {
        $mimetypes = $this->getMimeTypes();

        if (in_array($_FILES[$this->file_name]['type'], $mimetypes)) {
            return true;
        }
        return false;
    }

    private function checkFileSize()
    {
        if ($_FILES[$this->file_name]["size"] < $this->fileSize) {
            return true;
        }
        return false;
    }

    public function checkInteger($value)
    {
        return is_int($value);
    }
}

?>