<?php
class XmlGenerator{	

	public function genarateXML($premiums_arr)
	{
		//creating object of SimpleXMLElement
		$xml_user_info = new SimpleXMLElement("<?xml version=\"1.0\"?><policyinfo></policyinfo>");
		//function call to convert array to xml
		$this->array_to_xml($premiums_arr,$xml_user_info);		
		$filename = 'xml/Policies_Maturity'.time().'.xml';
		$xml_file = $xml_user_info->asXML($filename);
		return $filename;
	}
	//function defination to convert array to xml
	private function array_to_xml($array, &$xml_user_info) {
		foreach($array as $key => $value) {
			if(is_array($value)) {
				if(!is_numeric($key)){
					$subnode = $xml_user_info->addChild("$key");
					$this->array_to_xml($value, $subnode);
				}else{
					$subnode = $xml_user_info->addChild("item$key");
					$this->array_to_xml($value, $subnode);
				}
			}else {
				$xml_user_info->addChild("$key",htmlspecialchars("$value"));
			}
		}
	}
} 
?>