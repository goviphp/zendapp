<?php
use PHPUnit\Framework\TestCase;
use Configuration;

class ValidatorTest extends ConfigurationTest
{   
    private function getMimeTypesTest()
    {
        return [
            'text/csv',
            'text/plain',
            'application/csv',
            'text/comma-separated-values',
            'application/excel',
            'application/vnd.ms-excel',
            'application/vnd.msexcel',
            'text/anytext',
            'application/octet-stream',
            'application/txt',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        ];
    }
	
    public function checkUploadedFileTest()
    {
		//Checking uploaded file as correct type and size
        if ($_FILES[$this->file_name]["error"] == 0) {
            if (!$this->checkFileType() || !$this->checkFileSize()) {
                return 1;
            }
        }
        return 0;
    }	
	
    private function checkFileTypeTest()
    {
		//Get the mime types
        $mimetypes = $this->getMimeTypes();

		//Checking uploading file in correct mime type
        if (in_array($_FILES[$this->file_name]['type'], $mimetypes)) {
            return true;
        }
        return false;
    }
	
    private function checkFileSizeTest()
    {
		//Checking uploaded file in correct size
        if ($_FILES[$this->file_name]["size"] < $this->fileSize) {
            return true;
        }
        return false;
    }
}

?>