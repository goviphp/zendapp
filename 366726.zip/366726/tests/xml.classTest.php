<?php
use PHPUnit\Framework\TestCase;

class XmlGeneratorTEst{	

	public function genarateXMLTest($premiums_arr)
	{
		//creating object of SimpleXMLElement
		$xml_user_info = new SimpleXMLElement("<?xml version=\"1.0\"?><policyinfo></policyinfo>");
		//function call to convert array to xml
		$this->arrayToXML($premiums_arr,$xml_user_info);		
		$filename = 'xml/Policies_Maturity'.time().'.xml';
		$xml_file = $xml_user_info->asXML($filename);
		return $filename;
	}	
	
	private function arrayToXMLTest($array, &$xml_user_info) {
		//Generating XML from data array
		foreach($array as $key => $value) {
			if(is_array($value)) {
				if(!is_numeric($key)){
					$subnode = $xml_user_info->addChild("$key");
					$this->arrayToXML($value, $subnode);
				}else{
					$subnode = $xml_user_info->addChild("item$key");
					$this->arrayToXML($value, $subnode);
				}
			}else {
				$xml_user_info->addChild("$key",htmlspecialchars("$value"));
			}
		}
	}
} 
?>