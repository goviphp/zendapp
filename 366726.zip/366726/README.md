## Synopsis

RLG Policies Maturity Calculator is a micro project built in PHP (7.1.9) as part of Candidate Code Test. This doesn't connect/store in to any physical database.
Though the detailed folder structure is explained in the next section, src/index.php can be directly accessed from the web browser.

## Motivation

This project is created to demonstrate my understanding, designing, coding, testing and documentation skills. 

## Directory Structure

Root level will have the following directories and files:

**pseudo**        - Contains pseudo document provided initially

**src**           - Core files required for this project

**MaturityData.csv** - Sample data import file, created for verification

**Policies_Maturity.xml** - Generated XML file from MaturityData.csv upload

**tests**         - Test cases for the classes, can be run with phpUnit

**Readme.md**     - README file, outlines the overview of the project


## Installation

You should have a typical PHP environment like LAMP/XAMPP. Extract the project zip to the web root and src directory is the root of the project.

One can access src/index.php to run the script and the output is displayed. 

## src/xml 
This folder should have the right permissions to generate XML files

## Developer notes

*Environment and tools*
PHP - Version 7.1.6
Apache - Version 2.0


## WWW (What, Why and Ways)

### Configuration Class

What - Configuration class is used to parse the config file values.

Why - Insted of using the static values in code base, i have given the configurable variables in config.ini file, We can easily change the management fee, acceptable policy types etc in future.

Ways - Alternatively, we can declare these values in respective classes.

### Validator Class

What - Validation class to verify the uploaded data file.

Why - Server side validations for user input, if user has disabled the javascript and trying to upload the unacceptable data.

Ways - Has to upload data file has specified type and size.

### CSVReader Class

What - Read the data from uploaded file.

Why - User provided data file is input to generated desired xml, This class will reads and varify the mandatory values, if premiums, discretionary_bonus and uplift_percentage values are non numeric, then those rows are treated as invalid rows and same is updated in generated XML file.

Ways - Has to upload the data file as specified in sample file :  MaturityData.csv file


### Premium Class

What - This class has required business to generate the maturity values of uploaded policies.

Why - Each policy type has its own logic to generate the maturity value, based on user uploaded policies, i have calculated the management fee, discretionary bonus and uplift values to get the maturity.

Ways - We can change the values in configuration file to update the maturity values.

### XML Class

What - XML file generation

Why - Based on the generated maturity values for each policy, we need to generate the XML file. This XML will contains the Policy number and Maturity Value, error message has been set to invalid rows.

Ways - View/Download the generated XML files, these files are stored in src/xml folder.

### Test Cases

What - PHPUnit framework

Why - To execute and verify the test cases 

Ways - Due to time constrain, i am not able to execute the Test cases from PHPUnit.


