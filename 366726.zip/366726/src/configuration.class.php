<?php

/**
 * class        Configuration
 * @package     RLG Policies Maturity Calculator
 * @author      Siva <sivaramkrishna.nagotu@cognizant.com>
 */
class Configuration
{
    private $configFile = 'config.ini';
    private $items = [];

    function __construct()
    {
        $this->parse();
    }

    function __get($id)
    {
        return $this->items[$id];
    }
	
	/**
     * getManagementFee
     *
     * @param string $configFile Parse the configuration settings     
     * @return array
     */
    private function parse()
    {
        $this->items = parse_ini_file($this->configFile);
    }
}

?>