<?php
require_once("configuration.class.php");

/**
 * class        Validator
 * @package     RLG Policies Maturity Calculator
 * @author      Siva <sivaramkrishna.nagotu@cognizant.com>
 */
class Validator extends Configuration
{
    private $file_name;

    function __construct($fileName)
    {
        parent::__construct();
        $this->file_name = $fileName;
    }
	
	/**
     * getMimeTypes
     *      
     * @return array mime types 
     */
    private function getMimeTypes()
    {
        return [
            'text/csv',
            'text/plain',
            'application/csv',
            'text/comma-separated-values',
            'application/excel',
            'application/vnd.ms-excel',
            'application/vnd.msexcel',
            'text/anytext',
            'application/octet-stream',
            'application/txt',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        ];
    }
	
	/**
     * checkUploadedFile
     *      
     * @return 0 or 1 
     */
    public function checkUploadedFile()
    {
		//Checking uploaded file as correct type and size
        if ($_FILES[$this->file_name]["error"] == 0) {
            if (!$this->checkFileType() || !$this->checkFileSize()) {
                return 1;
            }
        }
        return 0;
    }
	
	/**
     * checkFileType
     *      
     * @return true or flase 
     */
    private function checkFileType()
    {
		//Get the mime types
        $mimetypes = $this->getMimeTypes();

		//Checking uploading file in correct mime type
        if (in_array($_FILES[$this->file_name]['type'], $mimetypes)) {
            return true;
        }
        return false;
    }
	
	/**
     * checkFileType
     *      
     * @return true or flase 
     */
    private function checkFileSize()
    {
		//Checking uploaded file in correct size
        if ($_FILES[$this->file_name]["size"] < $this->fileSize) {
            return true;
        }
        return false;
    }
}

?>