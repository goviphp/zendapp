<?php

/**
 * class        CSVReader
 * @package     RLG Policies Maturity Calculator
 * @author      Siva <sivaramkrishna.nagotu@cognizant.com>
 */
class CSVReader
{
    private $file_name;

    function __construct($fileName)
    {
        $this->file_name = $fileName;
    }
	
	/**
     * getData
     *
     * @param uploaded file
     * @return array file data
     */
    public function getData()
    {
		//Get the uploaded file
        $tmpName = $_FILES[$this->file_name]['tmp_name'];
		
		//Read the uploaded file and generate array
        if (($handle = fopen($tmpName, 'r')) !== FALSE) {
            // necessary if a large csv file
            set_time_limit(0);
			
            $row = 0;
            while (($data = fgetcsv($handle, 1000, ',')) !== FALSE) {
                if ($row == 0) {
                    $row++;
                    continue;
                }
                // number of fields in the csv
                $col_count = count($data);
                // get the values from the csv
                $csv[$row]['col1'] = $data[0];
                $csv[$row]['col2'] = $data[1];
				//check for integer value
                if (is_numeric($data[2])) {
                    $csv[$row]['col3'] = $data[2];
                } else {
                    $csv[$row]['col3'] = 0;
                }
                $csv[$row]['col4'] = $data[3];
				
				//check for integer value
                if (is_numeric($data[4])) {
                    $csv[$row]['col5'] = $data[4];
                } else {
                    $csv[$row]['col5'] = 0;
                }
				//check for integer value
                if (is_numeric($data[5])) {
                    $csv[$row]['col6'] = $data[5];
                } else {
                    $csv[$row]['col6'] = 0;
                }
                // inc the row
                $row++;
            }
            fclose($handle);
        }
        return $csv;
    }
}

?>