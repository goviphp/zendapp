<?php
//Verify form is submitted or not
if (empty($_POST['submit'])) {
    header('Location: index.php');
    exit;
}
require_once("validator.class.php");
require_once("csvreader.class.php");
require_once("premium.class.php");
require_once("xml.class.php");
$validator_obj = new Validator('dataFile');
$error = '';
//Verify server side validation for uploaded file
$error = $validator_obj->checkUploadedFile();
//If uploaded file has errors, return back to index
if ($error) {
    header('Location: index.php?error=1');
    exit;
}
//Read content from Data file
$csvreader_obj = new CSVReader('dataFile');
$csv_data = $csvreader_obj->getData();

//Calculate Maturity value
$premium_obj = new Premium($csv_data);
$premiums_arr = $premium_obj->getPremium();

//Generate xml from maturity array
$xml_obj = new XmlGenerator();
$filename = $xml_obj->genarateXML($premiums_arr);

//View generated XML file
if ($filename) {
    echo "<a href='" . $filename . "' target='_blank'>Click Here to View XML </a><br>
	<< <a href='./index.php'>Back</a>
	";
}
?>