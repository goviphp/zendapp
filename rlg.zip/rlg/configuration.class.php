<?php
class Configuration
{
	private $configFile = 'config.ini'; 
	private $items = array();  
	function __construct() { 
		$this->parse(); 
	}
	function __get($id) 
	{ 
		return $this->items[ $id ]; 
	}
	function parse()
	{
		$this->items = parse_ini_file($this->configFile);		
	}
}
?>