<?php
/**
* class 		Premium
* @package    	RLG Policies Maturity Calculator
* @author     	Siva <sivaramkrishna.nagotu@cognizant.com>
*/
class Premium extends Configuration
{
	private $data;	
	function __construct($data){	
		parent::__construct();
		$this->data = $data;				
	}
	/**
	   * Generated the Policy Number and Maturity value
       * @return array
     */
	public function getPremium()
	{	
		$premium_arr = array();
		$index = 0;
		foreach($this->data as $row){				
			$managent_fee_percentage = $this->getManagementFee($row['col1']);			
			$discretionary_bonus_flag = $this->checkDBonusCriteria($row['col1'],$row['col2'],$row['col4']);			
			if($discretionary_bonus_flag){				
				$discretionary_bonus = $row['col5'];
			} else {				
				$discretionary_bonus = 0;
			}
			$uplift_percentage = $row['col6'];
			$uplift= (100+$uplift_percentage)/100;			
			$premium = $this->getPremiumAmount($row['col3'],$managent_fee_percentage,$discretionary_bonus,$uplift);			
			$premium_arr[$index]['policynumber'] = $row['col1'];
			if($premium){
				$premium_arr[$index]['maturityvalue '] = $premium;
			} else {
				$premium_arr[$index]['error'] = "Invalid row in data file";
			}				
			$index++;
		}
		return $premium_arr;
    }// End of getPremium function
	
	/**       
       * getManagementFee 
       *       
       * @param integer $new_width  description
       * @param integer $new_height  description
       * @param string $directory  description
       * @return boolean
       */	
	private function getManagementFee($policy_number){		
		$fee_percentage = 0;				
		$firstCharacter = strtoupper(substr($policy_number, 0, 1));
		$policy_types = explode(",",$this->policyTypes);
		$management_fee = explode(",",$this->managementfee);		
		foreach($policy_types as $key => $type){
			if($firstCharacter == $type){				
				$fee_percentage = $management_fee[$key]; 				
			} 
		}
		return $fee_percentage;
	}
	private function checkDBonusCriteria($policy_number,$policy_date,$membership)
	{
		$firstCharacter = strtoupper(substr($policy_number, 0, 1));
		if(( $firstCharacter == 'A') && (strtotime($policy_date) < strtotime($this->discretionaryBonusCriteriaDate))){
			return true;
		} else if(( $firstCharacter == 'B') && (strtoupper($membership) == 'Y')){
			return true;
		} else if(( $firstCharacter == 'C') && (strtoupper($membership) == 'Y') && (strtotime($policy_date) < strtotime($this->discretionaryBonusCriteriaDate))){
			return true;
		} else {
			return false;
		}
	}
	private function getPremiumAmount($total_premiums,$mfp,$db,$uplift)
	{			
		if($mfp){
			return ($total_premiums - (($total_premiums*$mfp)/100) + $db) * $uplift;
		} else {
			return 0;
		}		
	}
} 
?>