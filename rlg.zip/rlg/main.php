<?php
if(empty($_POST['submit']))
{
		header('Location: index.php');
		exit;
}
require_once("validator.class.php");
require_once("csvreader.class.php");
require_once("premium.class.php");
require_once("xml.class.php");
$validator_obj = new Validator('dataFile');
$error = '';
$error = $validator_obj->checkUploadedFile();
if($error){
		header('Location: index.php?error=1');
		exit;
}
$csvreader_obj = new CSVReader('dataFile');
$csv_data = $csvreader_obj->getData();

$premium_obj = new Premium($csv_data);
$premiums_arr = $premium_obj->getPremium();


$xml_obj = new XmlGenerator();
$filename = $xml_obj->genarateXML($premiums_arr);

if($filename){
	echo "Please download the xml file from <a href='".$filename."' target='_blank'>Download</a>";
}
?>