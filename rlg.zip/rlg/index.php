<?php
require_once("configuration.class.php");
$config_obj = new Configuration();
$error_message = '';
if(isset($_GET['error']))
{
	$error_message = "Invalid data file, Please try again...";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>  
  <script src="js/rlg.js?v=2"></script>
  <link href="css/rlg.css?v=3" rel="stylesheet"/>
</head>
<body>
<div id="header">
        <div class="headerLogoWrapper span-2">
            <img class="royalLondonLogo" alt="royal london logo" src="images/RL-logo.png">
        </div>        
</div>
<nav class="navbar navbar-inverse">  
</nav>  
<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
      
    </div>
    <div class="col-sm-8 text-left"> 
      <h1>Policies Maturity Calculator</h1>
	  <div class="jumbotron">
		<p class="error">
				<?=$error_message?>
		</p>
		<form id="fileForm" method="post" class="form-horizontal" enctype="multipart/form-data" action="main.php">
		<input type="hidden" name="fileType" id="fileType" value="<?=$config_obj->fileType?>">
		<input type="hidden" name="fileSize" id="fileSize" value="<?=$config_obj->fileSize?>">
    <div class="form-group">
        <label class="col-sm-3 control-label">Date File</label>
        <div class="col-sm-5">
            <input type="file" class="form-control" name="dataFile" id="dataFile" accept=".<?=$config_obj->fileType?>" required />
			<p id="error1" class="error" style="display:none;">
				Invalid file format! File format must be <?=$config_obj->fileType?> only.
			</p>
			<p id="error2" class="error" style="display:none;">
				Maximum File Size Limit is <?=$config_obj->fileSize?>.
			</p>
        </div>
		<div class="col-sm-4">
			<input type="submit" name="submit" value="Upload">
		</div>	
    </div>  
	</form>
	</div>
    </div>
    <div class="col-sm-2 sidenav">
      
    </div>
  </div>
</div>

<footer class="container-fluid text-center">
  <p>® 2018 Royal London Group</p>
</footer>

</body>
</html>
