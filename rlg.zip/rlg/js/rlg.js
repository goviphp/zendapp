$( document ).ready(function() {	
	$('input[type="submit"]').prop("disabled", true);
	var flag=0;
	//binds to onchange event of your input field
	$('#dataFile').bind('change', function() {
		if ($('input:submit').attr('disabled',false)){
			$('input:submit').attr('disabled',true);
		}
		var fileType = $('#fileType').val();
		var fileSize = $('#fileSize').val();
		var ext = $('#dataFile').val().split('.').pop().toLowerCase();
		if ($.inArray(ext, [fileType]) == -1){
			$('#error1').slideDown("slow");
			$('#error2').slideUp("slow");
			flag=0;
		}else{
			var picsize = (this.files[0].size);
			if (picsize > (fileSize)){
				$('#error2').slideDown("slow");
				flag=0;
			}else{
				flag=1;
				$('#error2').slideUp("slow");
			}
			$('#error1').slideUp("slow");
			if (flag==1){
				$('input:submit').attr('disabled',false);
			}
		}
	});
});